/* Start Header -------------------------------------------------------
Copyright (C) 2017 DigiPen Institute of Technology.
Reproduction or disclosure of this file or its contents without the
prior written consent of DigiPen Institute of Technology is prohibited.
File Name: README.txt
Purpose: How to run this program
Language: C++ and Microsoft Compiler
Platform: Microsoft Visual Studio 2015 Community Version
Project: yeo.k_CS200_5
Author: Kacey Lei Yeo, yeo.k, 180008214
Creation date: 03/20/2017
- End Header --------------------------------------------------------*/

First, have Visual Studio 2015 installed or the latest version of Visual Studio.
Next, take the glut32.dll inside of the GL folder and place it inside of C:\Windows\SysWOW64.
Next, open Assignment 5.sln.
Next, you can set the mode to Debug Mode or Release Mode.
Finally, after everything is loaded click on Local Windows Debugger.

(In the case, you don't have the ability to place the glut32.dll in C:\Windows\SysWOW64. 
Run the program and it will say it failed because of the missing glut32.dll in the case of this occuring, 
go into the folder containing the Assignment 5.sln and either Release or Debug depending on which mode 
you are running in place the glut32.dll inside of it.)